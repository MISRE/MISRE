#ifndef RANDOMSET
#define RANDOMSET

#include "Estimate.h"

void RandomSet(V_SIZE_T &pool, size_t elementalSize, V_SIZE_T &subset);

#endif