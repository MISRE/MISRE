#ifndef NORMALIZE
#define NORMALIZE

#include <Eigen/Dense>
using Eigen::MatrixXd;

void Normalize(MatrixXd &, MatrixXd &);

#endif